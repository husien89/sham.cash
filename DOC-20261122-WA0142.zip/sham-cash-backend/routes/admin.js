const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');
const admin = require('../middleware/admin');

const router = express.Router();
router.use(auth, admin);

const validId = (id) => mongoose.Types.ObjectId.isValid(id);

// List all users
router.get('/users', async (req, res) => {
  const users = await User.find().select('-password').sort({ _id: -1 });
  res.json({ users });
});

// Set a user's balance to an exact value
router.patch('/users/:id/balance', async (req, res) => {
  const { balance } = req.body || {};
  if (!validId(req.params.id) || typeof balance !== 'number' || !isFinite(balance) || balance < 0) {
    return res.status(400).json({ message: 'Invalid id or balance' });
  }
  const user = await User.findByIdAndUpdate(req.params.id, { balance }, { new: true }).select('-password');
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json({ user });
});

// Add money to a user and log it as a transaction from the admin
router.post('/users/:id/credit', async (req, res) => {
  const { amount } = req.body || {};
  if (!validId(req.params.id) || typeof amount !== 'number' || !isFinite(amount) || amount <= 0) {
    return res.status(400).json({ message: 'Invalid id or amount' });
  }
  const user = await User.findByIdAndUpdate(req.params.id, { $inc: { balance: amount } }, { new: true }).select('-password');
  if (!user) return res.status(404).json({ message: 'User not found' });
  await Transaction.create({ sender: req.userId, receiver: user._id, amount });
  res.json({ user });
});

// Delete a user
router.delete('/users/:id', async (req, res) => {
  if (!validId(req.params.id)) return res.status(400).json({ message: 'Invalid id' });
  if (String(req.params.id) === String(req.userId)) {
    return res.status(400).json({ message: 'Cannot delete yourself' });
  }
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json({ deleted: true });
});

// All transactions in the system
router.get('/transactions', async (req, res) => {
  const transactions = await Transaction.find().sort({ date: -1 }).limit(500);
  res.json({ transactions });
});

module.exports = router;
