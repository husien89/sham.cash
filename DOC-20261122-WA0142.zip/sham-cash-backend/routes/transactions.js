const express = require('express');
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');

const router = express.Router();

router.get('/', auth, async (req, res) => {
  const list = await Transaction.find({
    $or: [{ sender: req.userId }, { receiver: req.userId }],
  }).sort({ date: -1 });

  const transactions = list.map((t) => ({
    _id: t._id,
    type: String(t.sender) === String(req.userId) ? 'send' : 'receive',
    amount: t.amount,
    date: t.date,
  }));
  res.json({ transactions });
});

module.exports = router;
