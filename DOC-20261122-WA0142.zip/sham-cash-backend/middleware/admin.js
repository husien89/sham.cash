const User = require('../models/User');

// Must run after auth.js. Checks the flag in the database, not in the token.
module.exports = async (req, res, next) => {
  try {
    const user = await User.findById(req.userId).select('isAdmin');
    if (!user || !user.isAdmin) return res.status(403).json({ message: 'Forbidden' });
    next();
  } catch (e) {
    res.status(500).json({ message: 'Admin check failed' });
  }
};
